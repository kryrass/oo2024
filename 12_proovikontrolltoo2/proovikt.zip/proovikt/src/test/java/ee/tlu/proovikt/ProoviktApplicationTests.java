package ee.tlu.proovikt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProoviktApplicationTests {

	@Test
	void contextLoads() {
	}

}
