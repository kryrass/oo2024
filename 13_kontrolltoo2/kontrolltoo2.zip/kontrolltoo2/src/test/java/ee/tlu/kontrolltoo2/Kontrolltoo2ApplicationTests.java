package ee.tlu.kontrolltoo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kontrolltoo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
