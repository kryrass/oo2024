package ee.tlu.kontrolltoo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kontrolltoo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Kontrolltoo2Application.class, args);
	}

}
